package Ass4;

import java.util.Comparator;

public class CompareToCostFor100Km implements Comparator <Vehicles> {

	@Override
	// To sort order Vehicles in an ascending order based on cost For 100 Km
	public int compare(Vehicles o1, Vehicles o2) {
		// TODO Auto-generated method stub
		if(o1.costFor100Km(new PetroleumType()) > (o2.costFor100Km(new PetroleumType()))){
			return 1;
		}
		else if(o1.costFor100Km(new PetroleumType()) < (o2.costFor100Km(new PetroleumType()))){
			return -1;
		}
		return 0;
	}

}
