package Ass4;

public abstract class Vehicles implements Comparable<Vehicles>, Cloneable {

	// Data fields
	protected String modelName; // Model name of a vehicle
	protected String vehicleType; // Vehicle type
	protected String modelNo; // Model number of a vehicle
	protected String Brand; // Company to produce the mode
	protected String engineType; // Type of the engine
	protected double tankSize; // Size of fuel tank
	protected double FuelConsumption; // Fuel consumption of a vehicle
	private int NumberOfSeats; // Number of seats in a vehicle
	private boolean airConditionON_Off;
	public Owner owner; // Owner of the vehicle

	// To calculate cost for running 100 Km
	public abstract double costFor100Km(PetroleumType p);

	// To calculate movable distance of a vehicle when the tank of the vehicle is filled fully
	public double MovableDistance() {
		if (airConditionON_Off) {
			// Fuel consumption of the Car increased by 10% when air-condition of the Car is ON
			if (vehicleType == "Car" || vehicleType == "car") {
				FuelConsumption = FuelConsumption + (FuelConsumption * 0.1);
			}
			// Fuel consumption of the Minivan and the Truck increased by 20% when air-condition of the Car is ON
			else {
				FuelConsumption = FuelConsumption + (FuelConsumption * 0.2);
			}
		}
		return tankSize * FuelConsumption;
	}

	public boolean isAirConditionON_Off() {
		return airConditionON_Off;
	}

	// To set the air-condition of the vehicle to ON/Off
	public void setAirConditionON_Off(boolean airConditionON_Off) {
		this.airConditionON_Off = airConditionON_Off;
	}

	// To set the air-condition of the vehicle to ON
	public abstract void setAirConditionON();

	// To set the air-condition of the vehicle to Off
	public abstract void setAirConditionOff();

	public int getNumberOfSeats() {
		return NumberOfSeats;
	}

	public void setNumberOfSeats(int numberOfSeats) throws IllegalArgumentException {
		// To check if the number of seats tank is a negative number
		if (numberOfSeats >= 0) {
			NumberOfSeats = numberOfSeats;
		} else {
			throw new IllegalArgumentException("Tank size cannot be negative");
		}
	}
	
	public String getVehicleType() {
		return vehicleType;
	}

	// To check whether the vehicle type is available or not
	public void setVehicleType(String vehicleType) throws IllegalArgumentException {
		try {
			if (vehicleType == "Car" || vehicleType == "Minivan" || vehicleType == "Truck")
				this.vehicleType = vehicleType;
		} catch (IllegalArgumentException exception) {
			System.out.println("The vehicle's type cannot be of this type");
		}
		this.vehicleType = vehicleType;
	}

	public String getModelName() {
		return modelName;
	}

	public void setModelName(String modelName) {
		this.modelName = modelName;
	}

	public String getModelNo() {
		return modelNo;
	}

	public void setModelNo(String modelNo) {
		this.modelNo = modelNo;
	}

	public String getBrand() {
		return Brand;
	}

	public void setBrand(String brand) {
		Brand = brand;
	}

	public String getEngineType() {
		return engineType;
	}

	// To check whether the engine type is available or not
	public void setEngineType(String engineType) throws IllegalArgumentException {
		try {
			if (this instanceof Car) {
				if (engineType.equalsIgnoreCase("Gasoline") || engineType.equalsIgnoreCase("Hybrid"))
					this.engineType = engineType;
			} else if (this instanceof Minivan) {
				if (engineType.equalsIgnoreCase("Gasoline") || engineType.equalsIgnoreCase("Dieseal")
						|| engineType.equalsIgnoreCase("Hybrid"))
					this.engineType = engineType;
			} else if (this instanceof Truck) {
				if (engineType.equalsIgnoreCase("Dieseal"))
					this.engineType = engineType;
			}
		} catch (IllegalArgumentException exception) {
			System.out.println("The vehicle's engine cannot be of this type");
		}
		this.engineType = engineType;
	}

	public double getTankSize() {
		return tankSize;
	}

	public void setTankSize(double tankSize) throws IllegalArgumentException {
		// To check if the size of fuel tank is a negative number
		if (tankSize >= 0) {
			this.tankSize = tankSize;
		} else {
			throw new IllegalArgumentException("Tank size cannot be negative");
		}
	}

	public double getFuelConsumption() {
		return FuelConsumption;
	}

	public void setFuelConsumption(double fuelConsumption) throws IllegalArgumentException {
		// To check if the fuel Consumption is a negative number
		if (fuelConsumption >= 0) {
			this.FuelConsumption = fuelConsumption;
		} else {
			throw new IllegalArgumentException("Fuel consumption cannot be negative");
		}
	}

	public Owner getOwner() {
		return owner;
	}

	public void setOwner(Owner owner) {
		this.owner = owner;
	}

	@Override
	public Object clone() throws CloneNotSupportedException {
		Vehicles o = (Vehicles) super.clone();
		o.owner = null;
		return o;
	}

	@Override
	public int compareTo(Vehicles o) {
		// To sort order Vehicles in an descending order based on vehicle brand
		return this.getBrand().compareTo(o.getBrand());
	}

	@Override
	public String toString() {
		return "VehicleType=" + vehicleType + ", modelName=" + modelName + ", modelNo=" + modelNo + ", Brand=" + Brand
				+ ", engineType=" + engineType + ", tankSize=" + tankSize + ", FuelConsumption=" + FuelConsumption
				+ ", owner=" + ((owner != null) ? owner.getName() : "null" + ", number of seats=" + getNumberOfSeats() 
				+ ", Moveable distance=" + MovableDistance());
	}

}
