package Ass4;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Driver {

	static ArrayList<Vehicles> objs = new ArrayList<>();
	
	public static void main(String[] args) throws CloneNotSupportedException, IOException {
		// TODO Auto-generated method stub

		PetroleumType petroleumType = new PetroleumType();
		Scanner input = new Scanner(System.in);
		double dieselPrice = 0;
		double gasolinePrice = 0;
		
		// To print a menu that allow user to select from them
		System.out.println("Menu:");
		System.out.println("1. Read the data about objects from the file �inputdata.txt� and store them in Arraylist.\n"
				+ "2. Set prices of petroleum.\n"
				+ "3. Print sorted order Vehicles in an ascending order based on costFor100Km.\n"
				+ "4. Print sorted order Vehicles in an ascending order based on owner name.\n"
				+ "5. Print sorted order Vehicles in an descending order based on vehicle brand.\n"
				+ "6. Clone Vehicle without owner.(Ask user to choice one object for cloning from Arraylist, after Listing them to user).\n"
				+ "7. Turn air-condition on.\n" + "8. Write Output on the �output.txt� file after sort them.\n"
				+ "9. Exit from System");
		System.out.println(" ");
		
		int x = 0;
		while (x != 9) {
			System.out.print("Please select from Menu:");
			 x = input.nextInt();
			if (x == 1) {
				// To Read the data about objects from the file "inputdata.txt"
				readFromInputData(input, petroleumType);
				System.out.println("Successfully read data from the file.");
				System.out.println(" ");
			}

			else if (x == 2) {
				// Read petroleum price from console (NIS/liter)
				System.out.println("Please enter price for Diesel:");
				dieselPrice = input.nextDouble();
				petroleumType.setDieselPrice(dieselPrice);
				System.out.println("Please enter price for Gasoline:");
				gasolinePrice = input.nextDouble();
				petroleumType.setGasolinePrice(gasolinePrice);
				for (Vehicles o : objs)
					o.costFor100Km(petroleumType);
				System.out.println(" ");
			}

			else if (x == 3) {
				// To print sorted order Vehicles in an ascending order based on cost for 100 Km
				Collections.sort(objs, new CompareToCostFor100Km());
				System.out.println("The information after sorting according to cost for 100Km:");
				for (Vehicles o : objs)
					System.out.println(o.toString());
				System.out.println(" ");
			}

			else if (x == 4) {
				// To print sorted order Vehicles in an ascending order based on owner name
				Collections.sort(objs, new CompareToOwnerName());
				System.out.println("The information after sorting according to owner name:");
				for (Vehicles o : objs)
					System.out.println(o.toString());
				System.out.println(" ");
			}

			else if (x == 5) {
				// To print sorted order Vehicles in an descending order based on vehicle brand
				Collections.sort(objs, Collections.reverseOrder());
				System.out.println("The information after sorting according to vehicle brand:");
				for (Vehicles o : objs)
					System.out.println(o.toString());
				System.out.println(" ");
			}

			else if (x == 6) {
				// To clone vehicle without owner
				System.out.println("Please select vehicle to clone:");
				int i = input.nextInt();
				while (true) {
					if (i >= objs.size()) {
						System.out.println("This vehicle doesn't exist:");
						System.out.println("Please select vehicle to clone:");
						i = input.nextInt();
						continue;
					}
					Vehicles v = (Vehicles) objs.get(i).clone();
					objs.add(v);
					break;
				}
				for (Vehicles o : objs)
					System.out.println(o.toString());
				System.out.println(" ");
			}

			else if (x == 7) {
				// To turn air-conditioner ON
				for (Vehicles o : objs) {
					if(o.getOwner() != null) {
					o.setAirConditionON_Off(true);
				    System.out.println(o.toString());
					}
				}
				System.out.println("The air-conditioner have turned on");
				System.out.println(" ");
			}

			else if (x == 8) {
				// To write Output on the "output.txt" file after sort them
				writeToOutput(petroleumType);
				System.out.println("Successfully write data to the file.");
				System.out.println(" ");
			}

			else {
				// To exit from System
				System.out.println("Exit from System");
				System.out.println(" ");
			}
		}

	}

	public static void readFromInputData(Scanner input, PetroleumType petroleumType) throws FileNotFoundException {
		input = new Scanner(new File("inputdata.txt"));
		 while (input.hasNext()) {
			String s = input.nextLine();
			String[] sArray = s.toString().split(","); // The line split when there is a comma
			
			// If the vehicle is a type of Car
			if (sArray[0].equalsIgnoreCase("Car")) {
				Car car = new Car();
				car.setVehicleType(sArray[0]);
				car.setModelName(sArray[1]);
				car.setModelNo(sArray[2]);
				car.setBrand(sArray[3]);
				Owner owner = new Owner();
				owner.setName(sArray[4]);
				car.setOwner(owner);
				car.setEngineType(sArray[5]);
				car.setTankSize(Double.parseDouble(sArray[6].trim()));
				car.setFuelConsumption(Double.parseDouble(sArray[7].trim()));
				car.setNumberOfSeats(Integer.parseInt(sArray[8].trim()));
				objs.add(car);
			}
			// If the vehicle is a type of Minivan
			else if (sArray[0].equalsIgnoreCase("Minivan")) {
				Minivan minivan = new Minivan();
				minivan.setVehicleType(sArray[0]);
				minivan.setModelName(sArray[1]);
				minivan.setModelNo(sArray[2]);
				minivan.setBrand(sArray[3]);
				Owner owner = new Owner();
				owner.setName(sArray[4]);
				minivan.setOwner(owner);
				minivan.setEngineType(sArray[5].trim());
				minivan.setTankSize(Double.parseDouble(sArray[6].trim()));
				minivan.setFuelConsumption(Double.parseDouble(sArray[7].trim()));
				minivan.setNumberOfSeats(Integer.parseInt(sArray[8].trim()));
				minivan.setHasAutoDoors(Boolean.valueOf(sArray[9]));
				objs.add(minivan);
			} 
			// If the vehicle is a type of Truck
			else if (sArray[0].equalsIgnoreCase("Truck")) {
				Truck truck = new Truck();
				truck.setVehicleType(sArray[0]);
				truck.setModelName(sArray[1]);
				truck.setModelNo(sArray[2]);
				truck.setBrand(sArray[3]);
				Owner owner = new Owner();
				owner.setName(sArray[4]);
				truck.setOwner(owner);
				truck.setEngineType(sArray[5]);
				truck.setTankSize(Double.parseDouble(sArray[6].trim()));
				truck.setFuelConsumption(Double.parseDouble(sArray[7].trim()));
				truck.setNumberOfSeats(Integer.parseInt(sArray[8].trim()));
				truck.setPower(Integer.parseInt(sArray[9].trim()));
				objs.add(truck);
			}

		}
		input.close();
	}
	
	
	public static void writeToOutput(PetroleumType petroleumType) throws IOException, IllegalArgumentException, NullPointerException{
		File output = new File("output.txt");

		try {
			FileWriter fileWriter = new FileWriter(output);
			for (Vehicles o : objs) {
				// If there is no owner of the vehicle
				if (o.getOwner().getName() == null) {
					fileWriter.write("There is no owner of the vehicle");
				}
				// If there is owner of the vehicle
				else if(o.getOwner() != null) {
				if (o instanceof Car) {
					Car car = (Car) o;
					// To print the car information inside the file by FileWriter
					fileWriter.write("ModelName: " + car.getModelName() + ", ModelNo: " + car.getModelNo() + ", Brand: "
							+ car.getBrand() + ", Owner: " + car.getOwner().getName() + ", EngineType: "
							+ car.getEngineType() + ", TankSize: " + car.getTankSize() + ", FuelConsumption: "
							+ car.getFuelConsumption() + ", NumberOfSeats: " + car.getNumberOfSeats()
							+ ", Movable distance: " + car.MovableDistance() + " km, Cost for 100 Km: "
							+ car.costFor100Km(petroleumType) + " NIS" + "\n");
					fileWriter.write("\n");
				} else if (o instanceof Minivan) {
					Minivan minivan = (Minivan) o;
					// To print the minivan information inside the file by FileWriter
					fileWriter.write("ModelName: " + minivan.getModelName() + ", ModelNo: " + minivan.getModelNo()
							+ ", Brand: " + minivan.getBrand() + ", Owner: " + minivan.getOwner().getName()
							+ ", EngineType: " + minivan.getEngineType() + ", TankSize: " + minivan.getTankSize()
							+ ", FuelConsumption: " + minivan.getFuelConsumption() + ", NumberOfSeats: "
							+ minivan.getNumberOfSeats() + ", HasAutoDoors: " + minivan.isHasAutoDoors()
							+ ", Movable distance: " + minivan.MovableDistance() + " km, Cost for 100 Km: "
							+ minivan.costFor100Km(petroleumType) + " NIS" + "\n");
					fileWriter.write("\n");
				} else if (o instanceof Truck) {
					Truck truck = (Truck) o;
					// To print the truck information inside the file by FileWriter
					fileWriter.write("ModelName: " + truck.getModelName() + ", ModelNo: " + truck.getModelNo()
							+ ", Brand: " + truck.getBrand() + ", Owner: " + truck.getOwner().getName()
							+ ", EngineType: " + truck.getEngineType() + ", TankSize: " + truck.getTankSize()
							+ ", FuelConsumption: " + truck.getFuelConsumption() + ", NumberOfSeats: "
							+ truck.getNumberOfSeats() + ", Power: " + truck.getPower() + ", Movable distance: "
							+ truck.MovableDistance() + " km, Cost for 100 Km: " + truck.costFor100Km(petroleumType)
							+ " NIS" + "\n");
					fileWriter.write("\n");
				}
			}
			}
			fileWriter.close();
		} catch (IOException exception) {
			System.out.println(exception.getMessage());
		} catch (IllegalArgumentException exception) {
			System.out.println(exception.getMessage());
		} catch (NullPointerException exception) {
				System.out.println(exception.getMessage());
			}
		
	}	

}

