package Ass4;

public class Truck extends Vehicles{

	// Data fields
	private boolean airConditionON_Off = false;
	private int power; // Horse Power of a vehicle's engine
	private int NumberOfSeats; // Number of seats in a vehicle

	public boolean isAirConditionON_Off() {
		return airConditionON_Off;
	}

	// To set the air-condition of the vehicle to ON/Off
	public void setAirConditionON_Off(boolean airConditionON_Off) {
		this.airConditionON_Off = airConditionON_Off;
	}

	public int getPower() {
		return power;
	}

	public void setPower(int power) throws IllegalArgumentException {
		// To check if the power is a negative number
		if (power >= 0) {
			this.power = power;
		} else {
			throw new IllegalArgumentException("Horse Power of a vehicle's engine cannot be negative");
		}
	}

	public int getNumberOfSeats() {
		return NumberOfSeats;
	}

	public void setNumberOfSeats(int numberOfSeats) throws IllegalArgumentException {
		// To check if the number of seats tank is a negative number
		if (numberOfSeats >= 0) {
			NumberOfSeats = numberOfSeats;
		} else {
			throw new IllegalArgumentException("Tank size cannot be negative");
		}
	}
	
	// To set the air-condition of the vehicle to ON
	@Override
	public void setAirConditionON() {
		// TODO Auto-generated method stub
		this.setAirConditionON_Off(true);
	}

	// To set the air-condition of the vehicle to Off
	@Override
	public void setAirConditionOff() {
		// TODO Auto-generated method stub
		this.setAirConditionON_Off(false);
	}

	// To Calculate cost for running 100 Kms
	@Override
	public double costFor100Km(PetroleumType p) {
		// TODO Auto-generated method stub
		if(airConditionON_Off == true) {
			// Fuel consumption of the Truck increased by 20% when air-condition of the truck is ON
			FuelConsumption = FuelConsumption + (FuelConsumption*0.2);
		}
		else {
			FuelConsumption = FuelConsumption + 0;
		}
		double costFor100km = (100/FuelConsumption) * p.getDieselPrice(); // Trucks use only diesel engine
		return costFor100km;
	}
	
	@Override
	public String toString() {
		return super.toString()+ " ,airConditionON_Off=" + airConditionON_Off + ", power=" + power + ", NumberOfSeats="
				+ NumberOfSeats;
	}

}
