package Ass4;

public class PetroleumType {
	
	// Data fields
	public static final int DIESEL = 1;
	public static final int GASOLINE = 2;
	private static double dieselPrice; // Price of a Diesel
	private static double gasolinePrice; // Price of a Gasoline

	public double getDieselPrice() {
		return dieselPrice;
	}
	
	@SuppressWarnings("static-access")
	public void setDieselPrice(double dieselPrice) {
		this.dieselPrice = dieselPrice;
	}
	
	public double getGasolinePrice() {
		return gasolinePrice;
	}
	
	@SuppressWarnings("static-access")
	public void setGasolinePrice(double gasolinePrice) {
		this.gasolinePrice = gasolinePrice;
	}
	
	@Override
	public String toString() {
		return " dieselPrice=" + dieselPrice + ", gasolinePrice=" + gasolinePrice;
	}

}
