package Ass4;

import java.util.GregorianCalendar;

public class Owner implements Cloneable {

	// Data fields
	String name; // Name of an owner
	String PIN; // PIN of an owner
	String Address; // Address of an owner
	String MobileNO; // Mobile number of an owner
	GregorianCalendar DateOBirth; // Date of birth of an owner

	public Owner() {
		this.name = "Sara";
	}
	
    public Owner(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPIN() {
		return PIN;
	}

	public void setPIN(String pIN) {
		PIN = pIN;
	}

	public String getAddress() {
		return Address;
	}

	public void setAddress(String address) {
		Address = address;
	}

	public String getMobileNO() {
		return MobileNO;
	}

	public void setMobileNO(String mobileNO) {
		MobileNO = mobileNO;
	}

	public GregorianCalendar getDateOBirth() {
		return DateOBirth;
	}

	public void setDateOBirth(GregorianCalendar dateOBirth) {
		DateOBirth = dateOBirth;
	}

	@Override
	public Object clone() throws CloneNotSupportedException {
		// To clone vehicle without owner
		Owner owner = (Owner) super.clone();
		return owner;
	}

	@Override
	public String toString() {
		return " PIN=" + PIN + ", Address=" + Address + ", MobileNO=" + MobileNO + ", DateOBirth="
				+ DateOBirth;
	}

}