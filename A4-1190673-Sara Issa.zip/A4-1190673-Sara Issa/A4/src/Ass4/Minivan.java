package Ass4;

public class Minivan extends Vehicles {

	// Data fields
	private int NumberOfSeats; // Number of seats in a vehicle
	private boolean airConditionON_Off = false;
	private boolean hasAutoDoors; // A vehicle's having auto door

	public int getNumberOfSeats() {
		return NumberOfSeats;
	}

	public void setNumberOfSeats(int numberOfSeats) throws IllegalArgumentException {
		// To check if the number of seats tank is a negative number
		if (numberOfSeats >= 0) {
			NumberOfSeats = numberOfSeats;
		} else {
			throw new IllegalArgumentException("Tank size cannot be negative");
		}
	}

	public boolean isAirConditionON_Off() {
		return airConditionON_Off;
	}

	// To set the air-condition of the vehicle to ON/Off
	public void setAirConditionON_Off(boolean airConditionON_Off) {
		this.airConditionON_Off = airConditionON_Off;
	}

	public boolean isHasAutoDoors() {
		return hasAutoDoors;
	}

	public void setHasAutoDoors(boolean hasAutoDoors) {
		this.hasAutoDoors = hasAutoDoors;
	}

	// To set the air-condition of the vehicle to ON
	@Override
	public void setAirConditionON() {
		this.setAirConditionON_Off(true);
	}

	// To set the air-condition of the vehicle to Off
	@Override
	public void setAirConditionOff() {
		this.setAirConditionON_Off(false);
	}

	// To Calculate cost for running 100 Kms
	@Override
	public double costFor100Km(PetroleumType p) {
		double costFor100km = 0;
		// Minivans can use engine of both gasoline and diesel
		if (engineType == " Diesel") {
			if (airConditionON_Off == true) {
				// Fuel consumption of the Minivan increased by 20% when air-condition of the minivan is ON
				FuelConsumption = FuelConsumption + (FuelConsumption * 0.2);
			} else {
				FuelConsumption = FuelConsumption + 0;
			}
			costFor100km = (100 / FuelConsumption) * p.getDieselPrice();
		} else {
			if (airConditionON_Off == true) {
				// Fuel consumption of the Minivan increased by 20% when air-condition of the minivan is ON
				FuelConsumption = FuelConsumption + (FuelConsumption * 0.2);
			} else {
				FuelConsumption = FuelConsumption + 0;
			}
			costFor100km = (100 / FuelConsumption) * p.getGasolinePrice();
		}
		return costFor100km;
	}

	@Override
	public String toString() {
		return super.toString() + " ,numberOfSeats=" + NumberOfSeats + ", airConditionON_Off=" + airConditionON_Off
				+ ", hasAutoDoors=" + hasAutoDoors;
	}

}
