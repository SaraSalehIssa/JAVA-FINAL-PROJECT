package Ass4;

import java.util.Comparator;

public class CompareToOwnerName implements Comparator <Vehicles> {

	@Override
	// To sort order Vehicles in an ascending order based on owner name
	public int compare(Vehicles o1, Vehicles o2) {
		// TODO Auto-generated method stub
		return o1.getOwner().getName().compareTo(o2.getOwner().getName());
	}

}
